package com.restapi.sample.userapp.user;

import java.net.URI;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.support.ServletUriComponentsBuilder;



@RestController
public class UserResource {

	@Autowired
	private UserRepository userRepository;
	
	@GetMapping("/users")
	public List<User> retrieveAllUsers() {
		return userRepository.findAll();
	}
	
	@GetMapping("/users/{id}")
	public User retrieveUser(@PathVariable long id) throws UserNotFoundException {
		Optional<User> user = userRepository.findById(id);

		if (!user.isPresent())
			throw new UserNotFoundException("id-" + id);

		return user.get();
	}
	
	@GetMapping("/users/{userName}/{password}")
	public User retrieveUser(@PathVariable String userName,@PathVariable String password) throws UserNotFoundException {
		List<User> userList=userRepository.findAll();
		for(User user:userList){	
			System.out.println(user.getUsername());
		if(user.getUsername().equalsIgnoreCase(userName)){
			return user;
		}
		}
			throw new UserNotFoundException("userName-" + userName);
	
	}
	
	@PostMapping("/users")
	public ResponseEntity<Object> createUser(@RequestBody User user) throws UserNotFoundException {
		List<User> userList=userRepository.findAll();
		for(User currentUser:userList){	
			String userName=user.getUsername();
		if(currentUser.getUsername().equalsIgnoreCase(userName.toLowerCase())){
			throw new UserNotFoundException("userName already Exist-" + user.getUsername());
		}
		}
				User savedUser = userRepository.save(user);
				URI location = ServletUriComponentsBuilder.fromCurrentRequest().path("/{id}")
						.buildAndExpand(savedUser.getId()).toUri();

				return ResponseEntity.created(location).build();
			}
				
			
		

	
	
}