
insert into user
values(10001,'india','ranga@gmail.com','kamz','male','Ranga','ranga','ranga');
